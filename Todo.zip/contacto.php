<?php

include 'config.php';

error_reporting (E_ALL ^ E_NOTICE);

$post = (!empty($_POST)) ? true : false;

if($post)
{
$subject = "Orden de Compra Nro: $_SESSION[orden]";


$error = '';
   $message ="	Datos de la Orden
				
				Orden: $_SESSION[orden]

				Usuario: $_SESSION[comprador]

				Persona o Empresa: $_SESSION[empresa]

				RIF: $_SESSION[rif]				

				Telefono: $_SESSION[telefono]

				Direccion: $_SESSION[direccion]

				Correo: $_SESSION[correo]
				
				";
   // Set From: header
   $from ="Tecnologia Climatica soporte@tecnologiaclimatica.com";
   // Email Headers
	$header= "From: soporte@tecnologiaclimatica.com\r\n";
	$header .= "X-Mailer: PHP/" . phpversion() . " \r\n";
	$header .= "Mime-Version: 1.0 \r\n";
	$header .= "Content-Type: text/plain"; - See more at: http://www.tallerwebmaster.com/tutorial/formulario-de-contacto-enviar-mail-con-php/43/#sthash.LjHkLqzT.dpuf


if(!$error)
{
$mail = mail(WEBMASTER_EMAIL, $subject, $message,$header);

if($mail)
{
echo "<script>
					<!--
					location.href='index.php';
					//-->
					</script>";
}

}
?>