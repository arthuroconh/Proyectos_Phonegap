<?PHP
	include 'establecerconexion.php';

	//obteniendo datos
	$nombre=$_POST['usu_nom'];
	$usu=$_POST['usu_usu'];
	$contrasenia=$_POST['usu_cla'];
	$correo=$_POST['usu_cor'];
	//pasando contraseña a MD5
	$contra=  md5($contrasenia);
	// insert de usuario
	$usuario="INSERT INTO `t_usu`(`usu_id`, `usu_usu`, `usu_cor`, `usu_nom`,`usu_tip`) VALUES ('','$usu','$correo','$nombre',2)";
	$insertar=mysql_query($usuario) or die('No se pudo insertar datos debido a: '. mysql_error());
	$insertar=array();	
	//insert de clave
	$a=mysql_query("select * from `t_usu` order by `usu_id` DESC limit 1") or die(mysql_error());
			while (	$f=mysql_fetch_array($a)) {
			$usu=$f['usu_id'];
		}
	$usuario="INSERT INTO `t_cla`(`cla_id`, `cla_cla`, `usu_id`) VALUES ('','$contra','$usu')";
	$insertar=mysql_query($usuario) or die('No se pudo insertar datos debido a: '. mysql_error());
	$insertar=array();	

include 'config.php';

error_reporting (E_ALL ^ E_NOTICE);

$post = (!empty($_POST)) ? true : false;

if($post)
{

$name = stripslashes($_POST['usu_nom']);
$cla = stripslashes($_POST['usu_cla']);
$email_clima='soporte@tecnologiaclimatica.com';
$email = trim($_POST['usu_cor']);
$subject = 'Datos de usuario';
$message = 'Bienvenido a la familia Tecnologia Climatica de Venezuela';


$error = '';   
   $message .= "Su usuario es: " . $name ;
   $message .= "Su clave es: " . $cla;
    $message .="Para solucionar cualquier duda no dede en contactarnos";
	if(!$error)
	{
		$mail = mail($email, $subject, $message,
		     "De: Tecnologia Climatica de Venezuela <".$email_clima.">\r\n"
		    ."Reply-To: ".$email_clima."\r\n"
		    ."X-Mailer: PHP/" . phpversion());

	}


}	if($mail){

	header("Location: registrado.php");
	}
?>