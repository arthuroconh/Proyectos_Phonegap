<?PHP session_start();
if($_SESSION['tipo_usuario']!=1){
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/estilos.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>

        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <header>
            <nav>
                <ul>
                    <a href="subir-producto.php"><li>Agregar Producto</li></a>
                    <a href="#"><li>Administrar Productos</li></a>
                    <a href="#"><li>Pedidos</li></a>
                    <a href="#"><li>Añadir informacion al soporte</li></a>
                   <a href="#"><li>Editar pagina principal</li></a>
                </ul>
            </nav>
        </header>
        <section class="contenedor">

            <section class="stock">
            <?PHP

                include ('establecerconexion.php');
                $_pagi_sql = "SELECT * FROM `t_pro`"; 

                //cantidad de resultados por página (opcional, por defecto 20) 
                $_pagi_cuantos = 6; 

                //Incluimos el script de paginación. Éste ya ejecuta la consulta automáticamente 
                include("paginator.inc.php"); 

                //Leemos y escribimos los registros de la página actual 
                while($row = mysql_fetch_array($_pagi_result)){ 
               
                ?>
                    <article class="contieneproducto">
                        <article class="producto">
                            <img src="productos/<?PHP echo $row['pro_img']?>" width="200px">
                            Nombre: <?PHP echo $row['pro_pro']?>
                            <a href="editar.php?pro_id=<?PHP echo $row['pro_id']?>">Editar</a>  
                        </article>           
                    </article> 

                <?PHP
                } 
                //Incluimos la barra de navegación 
                echo"<div class='posicionador'><p id='posicionarpaginacion'>".$_pagi_navegacion."</p></div>";
            ?>
            
            <a href="cerrar-sesion.php">cerrar sesion</a>
            </section>            
            </section>

            <a href="cerrar-sesion.php">cerrar sesion</a>
            </section>
        </section>
        
        <footer>
            
        </footer>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>
    </body>
</html>
