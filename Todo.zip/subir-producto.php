<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/estilos.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
    <?PHP
        include ('establecerconexion.php');
    ?>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <header>
            

        </header>
        <section clas="contenedor">
            <article class="contenedorformulario" onsubmit="return validacion()">
                <form id="formularionuevoproducto" method="POST" action="guardar-producto.php" enctype="multipart/form-data">
                    <div id="salto"><label>Nombre: </label><input type="text" name="pro_nom" required="required"></div>
                    <div id="salto"><label>Precio:</label><input type="number" step="any" id="precio" name="pro_pre" required="required"></div>
                    <div id="salto"><label>Descripcion:</label><input type="text" name="pro_des" required="required"></div>
                    <div id="salto"><label>Imagen:</label><input type="file"  name="pro_img" required="required"></div>
                    <div id="salto"><input type="submit" value="Guardar" id="Guardar" onclick="comprueba_extension(this.form, this.form.pro_img.value)"></div>                           
                </form>            
            </article>    
        </section>
        
        <footer>
            
        </footer>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        <script type="text/javascript">
        function validacion() {
            valor = document.getElementById("precio").value;
            if( isNaN(precio.value)>0 ) {
              return "";
            }
        }
        </script>

        <script type="text/javascript">
            function comprueba_extension(formulario, archivo) { 
               extensiones_permitidas = new Array(".gif", ".jpg", ".png"); 
               mierror = ""; 
               if (!archivo) { 
                  //Si no tengo archivo, es que no se ha seleccionado un archivo en el formulario 
                    mierror = "No has seleccionado ningún archivo"; 
               }else{ 
                  //recupero la extensión de este nombre de archivo 
                  extension = (archivo.substring(archivo.lastIndexOf("."))).toLowerCase(); 
                  //alert (extension); 
                  //compruebo si la extensión está entre las permitidas 
                  permitida = false; 
                  for (var i = 0; i < extensiones_permitidas.length; i++) { 
                     if (extensiones_permitidas[i] == extension) { 
                     permitida = true; 
                     break; 
                     } 
                  } 
                  if (!permitida) { 
                     mierror = "Comprueba la extensión de los archivos a subir. \nSólo se pueden subir archivos con extensiones: " + extensiones_permitidas.join(); 
                    }else{ 
                        //submito! 
                     alert ("Imgen Correcta"); 
                     return 1; 
                    } 
               } 
               //si estoy aqui es que no se ha podido submitir 
               alert (mierror); 
               return 0; 
            }
        </script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>
    </body>
</html>
