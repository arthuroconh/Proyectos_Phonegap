<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/estilos.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script type="text/javascript">
            var formatNumber = {
                     separador: ".", // separador para los miles
                     sepDecimal: ',', // separador para los decimales
                     formatear:function (num){
                      num +='';
                      var splitStr = num.split('.');
                      var splitLeft = splitStr[0];
                      var splitRight = splitStr.length > 1 ? this.sepDecimal + splitStr[1] : '';
                      var regx = /(\d+)(\d{3})/;
                      while (regx.test(splitLeft)) {
                      splitLeft = splitLeft.replace(regx, '$1' + this.separador + '$2');
                      }
                      return this.simbol + splitLeft  +splitRight;
                     },
                     new:function(num, simbol){
                      this.simbol = simbol ||'';
                      return this.formatear(num);
                     }
                }
                     window.onload = function(){
                        var form = document.forms.formulario;
                        form.oninput = function() {
                            form.total.value = form.pro_can.value*form.pro_pre.value;
                            var mi_numero=form.total.value;
                            mi_numero=mi_numero*100;
                            mi_numero=Math.floor(mi_numero);
                            mi_numero=mi_numero/100;
                            form.total.value=formatNumber.new(mi_numero, "Bs.");


                }
            }
        </script>
    </head>
    <body>
    <?PHP
        include ('establecerconexion.php');
        $id=$_GET['pro_id'];
        if (!isset($_GET['pro_id'])) {
            header('Location: administracion.php');
        }
    ?>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <header>
            

        </header>
        <section class="contenedor">
            <section class="stock">
            <?PHP
                $consulta = mysql_query("SELECT * FROM `t_pro` WHERE `t_pro`.`pro_id`=$id"); 
                $row = mysql_fetch_array($consulta); 
                $precio=$row['pro_pre'];
                $precio_arreglado= number_format( $precio , 2 , "," ,"." );
                ?>
                    <article class="contieneproducto">
                        <article class="producto">
                            <form action="actualizar.php" method="POST" name="formulario" enctype="multipart/form-data"> 
                                <img src="productos/<?PHP echo $row['pro_img']?>" width="200px">
                                Nombre:<input type="text" id="nombre" name="pro_nom" value="<?PHP echo $row['pro_pro']?>"><br>
                                Precio:<input type="text" id="precio" name="pro_pre" value="<?PHP echo $precio_arreglado;?>"><br>
                                Descripcion:<textarea name="pro_des"><?PHP echo $row['pro_des']?></textarea><br>
                                Imagen:<input type="file" name="pro_img"><br><br>
                                    <input type="text" name="pro_id" value="<?PHP echo $id?>" style="display:none">
                                    <input type="submit" value="Modificar">                              
                            </form>
                        </article>               
                    </article> 
            </section>
        </section>
        
        <footer>
            
        </footer>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>
    </body>
</html>
