<?php
session_start();
$subject = "Orden de Compra Nro: $_SESSION[orden]";
require "phpmailer/class.phpmailer.php";
$error = '';  
   $message ="	<h1>Datos de la Orden</h1><br><br><br>
				
				<b>Orden Nro:</b> $_SESSION[orden]<br><br>

				<b>Usuario:</b> $_SESSION[comprador]<br><br>

				<b>Persona o Empresa:</b> $_SESSION[empresa]<br><br>

				<b>RIF:</b> $_SESSION[rif]<br><br>			

				<b>Telefono:</b> $_SESSION[telefono]<br><br>

				<b>Direccion:</b> $_SESSION[direccion]<br><br>

				<b>Correo:</b> $_SESSION[correo]<br><br>
				
				";
   $message2 ="	Datos de la Orden
				
				Orden Nro:

				Usuario: $_SESSION[comprador]

				Persona o Empresa: $_SESSION[empresa]

				RIF: $_SESSION[rif]			

				Telefono: $_SESSION[telefono]

				Direccion: $_SESSION[direccion]

				Correo: $_SESSION[correo]
				
				";

if(!$error)
{
$mail = mail('contacto@desarrollotricolor.com.ve', $subject, $message2,
     "From: Tecnologia Climatica soporte@tecnologiaclimatica.com\r\n"
    ."Reply-To: soporte@tecnologiaclimatica.com\r\n"
    ."X-Mailer: PHP/" . phpversion());


$mail = new PHPMailer;
$mail ->Host = "www.desarrollotricolor.com.ve";
$mail ->From = "soporte@tecnologiaclimatica.com";
$mail ->FromName = "Orden de Compra en Tecnologiaclimatica.com";
$mail ->Subject = $subject;
$mail ->addAddress($_SESSION[correo], $_SESSION[empresa]);
$mail ->MsgHTML($message);

if ($mail->Send()) {
	echo "<script>
					<!--
					location.href='index.php';
					//-->
					</script>";
}

if($mail)
{
echo "<script>
					<!--
					location.href='index.php';
					//-->
					</script>";
}

}

?>